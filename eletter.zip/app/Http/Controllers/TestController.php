<?php

namespace App\Http\Controllers;

use App\Http\Controllers\AdminKemahasiswaanController;

class TestController extends AdminKemahasiswaanController
{
    public function index()
    {
        return 'Test Controller Works!';
    }
}
