<?php

namespace App\Livewire\Dashboard\SekretarisUmum;

use Livewire\Component;

class SuratPengurusCreate extends Component
{
    public function render()
    {
        return view('livewire.dashboard.sekretaris-umum.surat-pengurus-create');
    }
}
