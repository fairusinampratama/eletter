<?php

namespace App\Livewire;

use Livewire\Component;

class TableFilters extends Component
{
    public function render()
    {
        return view('livewire.table-filters');
    }
}
