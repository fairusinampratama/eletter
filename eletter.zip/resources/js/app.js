import "./bootstrap";

// Alpine.js is initialized by Livewire
