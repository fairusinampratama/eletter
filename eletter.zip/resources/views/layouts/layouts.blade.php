<!DOCTYPE html>
<html>

<head>
    <title>Test Layout</title>
</head>

<body>
    @yield('content')
</body>

</html>