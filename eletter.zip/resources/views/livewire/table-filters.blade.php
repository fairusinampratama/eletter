<div>
    {{-- Nothing in the world is as soft and yielding as water. --}}
</div>
